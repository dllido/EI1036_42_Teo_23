<!DOCTYPE html>
<html lang="es">

<head>
	<meta charset="UTF-8">
	<title>Portal Pruebas </title>
	<meta name="Author" content="AlumnoXXX">
	<link rel="stylesheet" href="./css/estilo.css" type="text/css">
	<link rel="icon" type="image/ico" href="./media/favicon.ico">

</head>


<body>
	<header>
		<img src="./media/imagen1.png" id="logo" alt="logo" />
		<h1 id="eslogan"> Mi primer portal</h1>
	</header>