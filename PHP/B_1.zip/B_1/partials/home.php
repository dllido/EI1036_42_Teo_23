<main>
	<h2>Bienvenidos</h2>
	<p>Visita todas nuestras seciones </p>
</main>