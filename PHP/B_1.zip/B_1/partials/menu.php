<nav>
	<ul>
		<li>
			<a href="?action=home">Home</a>
		</li>
		<li>
			<a href="?action=form_register">Registro</a>
		</li>
		<li>
			<a href="?action=list">Listar</a>
		</li>

		<li>
			<a href="?action=modify">Modificar</a>
		</li>
		<li>
			<a href="../B_0/holaMundo.php">HolaMundo</a>
		</li>
	</ul>
</nav>