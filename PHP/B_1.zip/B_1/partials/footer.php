<footer>
	<img src="https://licensebuttons.net/l/by-sa/3.0/88x31.png" alt="licencia" />
	<time datetime="2023-09-18">2023</time><br/>
	<address>
		<p class="izq"> Written by
			<a href="mailto:webmaster@example.com" rev="author">Jon Doe</a>.</p>
		<p class="der"> Visit us at:Box 564, Disneyland, USA </p>
	</address>
</footer>
</body>

</html>