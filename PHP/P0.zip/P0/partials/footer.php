<footer>
	<img src="https://licensebuttons.net/l/by-sa/3.0/88x31.png" height="31px" />
	<time datetime="2018-09-18">2018</time>.</p>
	<address>
		<p class="izq"> Written by
			<a href="mailto:webmaster@example.com" rev="author">Jon Doe</a>.</p>
		<p class="der"> Visit us at:Box 564, Disneyland, USA </p>
	</address>
</footer>
</body>

</html>